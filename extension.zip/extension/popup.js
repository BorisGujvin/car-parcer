const grabBtn = document.getElementById("grabBtn");
grabBtn.addEventListener("click",() => {    
    chrome.tabs.query({active: true}, function(tabs) {
        var tab = tabs[0];
        if (tab) {
            chrome.scripting.executeScript(
                {
                    target:{tabId: tab.id, allFrames: false},
                    func:grabImages
                },
                onResult
            )
        } else {
            alert("There are no active tabs")
        }
    })
})


function grabImages() {
    const getId = function () {
        let id = null
        try {
            const url = window.location.href
            if (!url.startsWith('https://suchen.mobile.de/fahrzeuge/details.html')) {
                return null
            }
            const parameter = url.split('?')[1].split('&')[0]
            if (!parameter.startsWith('id')) {
                return null
            }
            id = parameter.split('=')[1];
        } catch {}
        console.log(id)
        return id
    }
    const id = getId()
    if (id) {
        window.location.href = "http://trasiett.com/redirect-from-mobile-de?mobile-id=" + id;
    } else {
        console.log('wrong page')
    }
}

function onResult(frames) {}